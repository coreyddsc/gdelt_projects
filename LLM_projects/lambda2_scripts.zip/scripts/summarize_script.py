import sys
print(sys.executable)
import json
from transformers import pipeline, set_seed
set_seed(42)

# Initialize summarization pipeline
# pipe_summary = pipeline("summarization", model="t5-large", device=1, truncation=True)
pipe_summary = pipeline("summarization", model="facebook/bart-large-cnn", device=1, truncation=True)


def main():
    # Read input from stdin
    input_text = sys.stdin.read().strip()
    
    # Truncate input text to fit within the model's capacity (max ~1024 tokens for BART)
    max_input_length = 1024  # Adjust for your model's maximum token length
    truncated_text = input_text[:max_input_length]
    
    try:
        # Perform summarization
        summary = pipe_summary(
            truncated_text,
            max_length=400,  # Adjust based on summary needs
            min_length=300,  # Ensure output isn't too short
            do_sample=False,  # Deterministic results
            early_stopping=True  # Stop decoding when criteria met
        )[0]["summary_text"]

        # Return the result as JSON
        print(json.dumps({"summary": summary}))
    
    except Exception as e:
        # Handle and log errors
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()

